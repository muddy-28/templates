-- phpMyAdmin SQL Dump
-- version 4.3.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 14, 2015 at 11:37 AM
-- Server version: 5.6.23
-- PHP Version: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `school1`
--

-- --------------------------------------------------------

--
-- Table structure for table `adm_fee`
--

CREATE TABLE IF NOT EXISTS `adm_fee` (
  `id` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `student_id` int(11) NOT NULL,
  `amount` int(5) NOT NULL,
  `voucher_no` varchar(10) NOT NULL,
  `deleted_at` date DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `batch`
--

CREATE TABLE IF NOT EXISTS `batch` (
  `id` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `batch_name` varchar(50) NOT NULL,
  `batch_year` varchar(4) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `c_code` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `discount_category`
--

CREATE TABLE IF NOT EXISTS `discount_category` (
  `id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(50) DEFAULT NULL,
  `percentage` int(2) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `dob` varchar(40) NOT NULL,
  `martial_status` varchar(12) NOT NULL,
  `children_count` int(2) DEFAULT NULL,
  `father_name` varchar(30) NOT NULL,
  `father_cnic` varchar(13) NOT NULL,
  `mother_name` varchar(30) NOT NULL,
  `blood_group` varchar(2) NOT NULL,
  `husband_name` varchar(30) DEFAULT NULL,
  `husband_cnic` varchar(13) DEFAULT NULL,
  `address` varchar(300) NOT NULL,
  `cnic` varchar(13) NOT NULL,
  `email` varchar(60) DEFAULT NULL,
  `contact_no` varchar(15) NOT NULL,
  `created_at` varchar(40) NOT NULL,
  `created_by` int(11) NOT NULL,
  `updated_at` varchar(40) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` varchar(40) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employee_acedemics`
--

CREATE TABLE IF NOT EXISTS `employee_acedemics` (
  `id` int(11) NOT NULL,
  `acedemic_year` varchar(20) NOT NULL,
  `acedemic_title` varchar(50) NOT NULL,
  `total_marks` int(5) NOT NULL,
  `obtained_marks` int(5) NOT NULL,
  `grade/cgpa/division` varchar(5) NOT NULL,
  `remarks` varchar(50) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` varchar(40) NOT NULL,
  `deleted_by` int(11) NOT NULL,
  `deleted_at` varchar(40) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` varchar(40) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `employee_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `employee_type`
--

CREATE TABLE IF NOT EXISTS `employee_type` (
  `id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` date NOT NULL,
  `deleted_by` int(11) NOT NULL,
  `deleted_at` date NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `employee_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `emp_type`
--

CREATE TABLE IF NOT EXISTS `emp_type` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` date NOT NULL,
  `deleted_by` int(11) NOT NULL,
  `deleted_at` date NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `extra_activities`
--

CREATE TABLE IF NOT EXISTS `extra_activities` (
  `studend_id` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` date NOT NULL,
  `deleted_by` int(11) NOT NULL,
  `deleted_at` date NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `category` varchar(30) NOT NULL,
  `description` varchar(100) NOT NULL,
  `year` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fee`
--

CREATE TABLE IF NOT EXISTS `fee` (
  `id` int(11) NOT NULL,
  `craeted_by` int(11) DEFAULT NULL,
  `created_at` date DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` date DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `class_id` int(11) DEFAULT NULL,
  `tution` int(5) DEFAULT NULL,
  `sports` int(5) DEFAULT NULL,
  `exam` int(5) DEFAULT NULL,
  `library` int(5) DEFAULT NULL,
  `total` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `parent`
--

CREATE TABLE IF NOT EXISTS `parent` (
  `id` int(11) NOT NULL,
  `created_at` varchar(40) NOT NULL,
  `updated_at` varchar(40) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `email` varchar(70) DEFAULT NULL,
  `cell_no` varchar(11) NOT NULL,
  `home_phone` varchar(11) DEFAULT NULL,
  `work_phone` varchar(11) DEFAULT NULL,
  `office_address` varchar(200) DEFAULT NULL,
  `dob` varchar(40) NOT NULL,
  `occupation` varchar(50) NOT NULL,
  `monthly_income` int(7) NOT NULL,
  `education` varchar(50) NOT NULL,
  `deleted_at` varchar(40) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `parent`
--

INSERT INTO `parent` (`id`, `created_at`, `updated_at`, `is_deleted`, `created_by`, `updated_by`, `first_name`, `last_name`, `email`, `cell_no`, `home_phone`, `work_phone`, `office_address`, `dob`, `occupation`, `monthly_income`, `education`, `deleted_at`, `deleted_by`) VALUES
(3, '55', NULL, 0, 55, NULL, '55', '55', NULL, '55', NULL, NULL, NULL, '55', '55', 55, '55', NULL, NULL),
(4, '2', NULL, 0, 22, NULL, '2', '2', '2', '22', '2', '2', '2', '22', '2', 2, '2', NULL, NULL),
(5, '2', NULL, 0, 22, NULL, '2', '2', '2', '22', '2', '2', '2', '22', '2', 2, '2', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL,
  `role` varchar(60) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `is_deleted`, `name`, `role`) VALUES
(4, 0, 'Manager', 'Manager');

-- --------------------------------------------------------

--
-- Table structure for table `section`
--

CREATE TABLE IF NOT EXISTS `section` (
  `id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` date NOT NULL,
  `deleted_by` int(11) NOT NULL,
  `deleted_at` date NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `section_incharge`
--

CREATE TABLE IF NOT EXISTS `section_incharge` (
  `id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `employee_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `deleted_by` int(11) NOT NULL,
  `deleted_at` date NOT NULL,
  `updated_by` int(11) NOT NULL,
  `updated_at` date NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` int(11) NOT NULL,
  `roll_no` int(10) NOT NULL,
  `admission_date` varchar(40) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(20) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `dob` varchar(40) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `blood_group` varchar(2) NOT NULL,
  `religion` varchar(20) NOT NULL,
  `address` varchar(200) NOT NULL,
  `cell_no` varchar(11) NOT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `parent_id` int(11) NOT NULL,
  `relation` varchar(20) NOT NULL,
  `last_institute` varchar(50) NOT NULL,
  `last_year` varchar(4) NOT NULL,
  `last_total` int(5) NOT NULL,
  `last_obtained` int(5) NOT NULL,
  `entry_total` int(5) NOT NULL,
  `entry_obtained` int(5) NOT NULL,
  `remarks` varchar(200) NOT NULL,
  `created_at` varchar(40) NOT NULL,
  `updated_at` varchar(40) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `deleted_at` varchar(40) DEFAULT NULL,
  `deleted_by` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `roll_no`, `admission_date`, `first_name`, `last_name`, `batch_id`, `dob`, `gender`, `blood_group`, `religion`, `address`, `cell_no`, `photo`, `parent_id`, `relation`, `last_institute`, `last_year`, `last_total`, `last_obtained`, `entry_total`, `entry_obtained`, `remarks`, `created_at`, `updated_at`, `is_deleted`, `created_by`, `updated_by`, `deleted_at`, `deleted_by`) VALUES
(5, 1, '1', '1', '1', 1, '11', '', '1', '1', '11', '1', NULL, 1, '1', '11', '1', 1, 11, 1, 1, '1', '11', NULL, 0, 1, NULL, NULL, NULL),
(7, 2, '2', '2', '2', 22, '2', '', '2', '2', '22', '2', NULL, 4, '2', '2', '22', 2, 2, 2, 22, '2', '2', NULL, 0, 22, NULL, NULL, NULL),
(8, 2, '2', '2', '2', 22, '2', '', '2', '2', '22', '2', NULL, 5, '2', '2', '22', 2, 2, 2, 22, '2', '2', NULL, 0, 22, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `stu_class`
--

CREATE TABLE IF NOT EXISTS `stu_class` (
  `id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `deleted_at` date NOT NULL,
  `deleted_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stu_fee`
--

CREATE TABLE IF NOT EXISTS `stu_fee` (
  `id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date NOT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `created_by` int(11) NOT NULL,
  `updated_by` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `fee_id` int(11) NOT NULL,
  `discount` int(5) NOT NULL,
  `fine` int(5) NOT NULL,
  `total` int(5) NOT NULL,
  `deleted_at` date NOT NULL,
  `deleted_by` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_by` int(11) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_by` int(11) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `role_id`, `created_by`, `created_at`, `updated_by`, `updated_at`, `deleted_by`, `deleted_at`, `is_deleted`) VALUES
(4, 'test1', '202cb962ac59075b964b07152d234b70', 7, NULL, '2015-09-12 08:08:45', NULL, '2015-09-12 08:08:45', NULL, '2015-09-12 08:08:45', 0),
(5, 'test2', '202cb962ac59075b964b07152d234b70', 7, NULL, '2015-09-12 08:09:30', NULL, '2015-09-12 08:09:30', NULL, '2015-09-12 08:09:30', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adm_fee`
--
ALTER TABLE `adm_fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `batch`
--
ALTER TABLE `batch`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `discount_category`
--
ALTER TABLE `discount_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_acedemics`
--
ALTER TABLE `employee_acedemics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee_type`
--
ALTER TABLE `employee_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `emp_type`
--
ALTER TABLE `emp_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `extra_activities`
--
ALTER TABLE `extra_activities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fee`
--
ALTER TABLE `fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `parent`
--
ALTER TABLE `parent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `section`
--
ALTER TABLE `section`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `section_incharge`
--
ALTER TABLE `section_incharge`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stu_class`
--
ALTER TABLE `stu_class`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stu_fee`
--
ALTER TABLE `stu_fee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `batch`
--
ALTER TABLE `batch`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `discount_category`
--
ALTER TABLE `discount_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `employee_acedemics`
--
ALTER TABLE `employee_acedemics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `employee_type`
--
ALTER TABLE `employee_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `emp_type`
--
ALTER TABLE `emp_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `extra_activities`
--
ALTER TABLE `extra_activities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `fee`
--
ALTER TABLE `fee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `parent`
--
ALTER TABLE `parent`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `section`
--
ALTER TABLE `section`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `section_incharge`
--
ALTER TABLE `section_incharge`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `stu_class`
--
ALTER TABLE `stu_class`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `stu_fee`
--
ALTER TABLE `stu_fee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
