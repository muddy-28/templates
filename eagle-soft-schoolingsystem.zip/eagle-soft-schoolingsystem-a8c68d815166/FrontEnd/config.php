
<?php
//configuration file which have a connection to the server
$_server = "http://localhost/BitBucket/SchoolingSystem/api/";
?>