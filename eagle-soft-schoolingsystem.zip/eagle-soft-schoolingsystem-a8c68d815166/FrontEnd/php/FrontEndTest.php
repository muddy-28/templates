<?php
Include("../Send.php");
//$var = sendRequest("authenticate","placeholder",0);
//var_dump($var);

if (isset($_POST['log'])) {
	//echo "string";
	$result = sendRequest("logout","placeholder",$_POST['t']);
	 if($result['success'])
{
	//echo "string Redirecting...".$_POST['t'];
	echo '<script>window.location.href = "login.php?E3";</script>';
}
}


$type = $var['userType'];
//echo "send: ".$_GET['a'];
//var_dump($var);
if (isset($_GET['E'])) {
	echo "<br>You don't have priviliges for this operation<br><br>";
}else if (isset($_GET['E1'])) {
	echo "<br>No any session started!!!<br><br>";
}



echo "<br>What You Want To Do???";
?>
<br/>
<a href="add_Student.php?t=<?php echo $_GET['a']; ?>">Add Student</a><br/>
<a href="add_role.php?t=<?php echo $_GET['a']; ?>" >Add Role</a><br/>
<a href="add_User.php">Add User</a><br/>
<a href="add_Employee.php?t=<?php echo $_GET['a']; ?>">Add Employee</a><br/>
<a href="add_Class.php">Add Class</a><br/>

<br/><br/>
<form action="" method="post">
	<input type="hidden" name="t" value=<?php echo $_GET['a']; ?> >
	<button type="submit" name="log" >Logout</button> 
</form>
