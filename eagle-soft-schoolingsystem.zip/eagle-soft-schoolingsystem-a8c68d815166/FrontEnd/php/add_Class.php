<?php
Include("../Send.php");
if(isset($_POST['SubmitButton']))
{
	$name        = $_POST['name'];
	$code        = $_POST['code'];
    $myArray = array('name' => $name,'code' => $code);
    echo sendRequest("Insert","CLASS",$myArray);
}
$var = sendRequest("authenticate","placeholder",0);

if($var['userType'] == NULL)
{
  echo '<script>window.location.href = "FrontEndTest.php?E1";</script>';
}

if($var['userType'] == -1)
{
  echo '<script>window.location.href = "login.php?E4";</script>';
}
else if ($var['userType'] != 7)
{
  //echo '<script>alert("You don,t have priviliges for this operation");</script>';
  echo '<script>window.location.href = "FrontEndTest.php?E";</script>';
}
else
{
?>
<form method="post">
<div>
	<label>Class Name:</label>
	<input type="text" placeholder="Class Name" name="name" required>
	<br/><br/>
	<label>Class Code:</label>
	<input type="text" placeholder="Class Code" name="code" required>
	<br/><br/>
	<button type="submit" name='SubmitButton'>Add</button>
</div>
</form>
<?php } ?>