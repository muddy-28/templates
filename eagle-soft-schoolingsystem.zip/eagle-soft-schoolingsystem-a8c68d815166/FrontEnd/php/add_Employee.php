<?php
Include("../Send.php");
if(isset($_POST['SubmitButton']))
{
	$code     		 = $_POST['code'];
	$meritalstatus   = $_POST['meritalstatus'];
	$fname       	 = $_POST['fname'];
	$lname           = $_POST['lname'];
	$fathername      = $_POST['fathername'];
	$dob             = $_POST['dob'];
	$sex             = $_POST['sex'];
	$childrens       = $_POST['childrens'];
	$fcnic        	 = $_POST['fcnic'];
	$mothername      = $_POST['mothername'];
	$bloodgroup      = $_POST['bloodgroup'];
	$husbandname     = $_POST['husbandname'];
	$husbandcnic  	 = $_POST['husbandcnic'];
	$address         = $_POST['address'];
	$cnic            = $_POST['cnic'];
	$email           = $_POST['email'];
	$contactno       = $_POST['contactno'];
	$createddate     = $_POST['createddate'];
	$createdby       = $_POST['createdby'];
	$tokken          = $_POST['t'];


    $myArray = array('code' => $code,'meritalstatus' => $meritalstatus,'fname' => $fname,'lname' => $lname,'fathername' => $fathername,'dob' => $dob,'gender' => $sex ,'childrens' => $childrens,'fcnic' => $fcnic,'mothername' => $mothername,'bloodgroup' => $bloodgroup, 'husbandname' => $husbandname,'husbandcnic' => $husbandcnic,'address' => $address,'cnic' => $cnic,'email' => $email,'contactno' => $contactno, 'createddate' => $createddate,'createdby' => $createdby, 'tokken' => $tokken );

    echo sendRequest("Insert","EMPLOYEE",$myArray);
}
$var = sendRequest("authenticate","placeholder",0);
if($var['userType'] == NULL)
{
  echo '<script>window.location.href = "FrontEndTest.php?E1";</script>';
}

if($var['userType'] == -1)
{
  echo '<script>window.location.href = "login.php?E4";</script>';
}
else
{

?>

<form method="post">
<div>
	<label>Employee Code:</label>
	<input type="text" placeholder="First Name" name="code" required>
	<br/><br/>
	<label>First Name:</label>
	<input type="text" placeholder="First Name" name="fname" required>
	<br/><br/>
	<label>Last Name:</label>
	<input type="text" placeholder="Last Name" name="lname" required>
	<br/><br/>
	<label>DOB:</label>
	<input type="text" placeholder="First Name" name="dob" required>
	<br/><br/>
	<label>Gender:</label>
	<input type="radio" name="sex" value="M" checked>Male
	<input type="radio" name="sex" value="F">Female
	<br><br>
	<label>Merital Status:</label>
	<input type="text" placeholder="First Name" name="meritalstatus" required>
	<br/><br/>
	<label>Children Count:</label>
	<input type="text" placeholder="First Name" name="childrens" required>
	<br/><br/>
	<label>Father Name:</label>
	<input type="text" placeholder="Address" name="fathername" required>
	<br/><br/>
	<label>Father CNIC:</label>
	<input type="text" placeholder="First Name" name="fcnic" required>
	<br/><br/>
	<label>Mother Name:</label>
	<input type="text" placeholder="First Name" name="mothername" required>
	<br/><br/>
	<label>Blood Group:</label>
	<input type="text" placeholder="First Name" name="bloodgroup" required>
	<br/><br/>
	<label>Husband Name:</label>
	<input type="text" placeholder="First Name" name="husbandname" required>
	<br/><br/>
	<label>Husband CNIC:</label>
	<input type="text" placeholder="First Name" name="husbandcnic" required>
	<br/><br/>
	<label>Address:</label>
	<input type="text" placeholder="First Name" name="address" required>
	<br/><br/>
	<label>CNIC:</label>
	<input type="text" placeholder="First Name" name="cnic" required>
	<br/><br/>
	<label>Email:</label>
	<input type="text" placeholder="First Name" name="email" required>
	<br/><br/>
	<label>Contact No:</label>
	<input type="text" placeholder="First Name" name="contactno" required>
	<br/><br/>
	<label>Created At:</label>
	<input type="text" placeholder="First Name" name="createddate" required>
	<br/><br/>
	<label>Created By:</label>
	<input type="text" placeholder="First Name" name="createdby" required>
	<br/><br/>
	<input type="hidden" name="t" value=<?php echo $_GET['t']; ?> >
	<h3>Please Insert Employe Qualification!!!</h3>



	<button type="submit" name='SubmitButton'>Add</button>
</div>
</form>
<?php } ?>