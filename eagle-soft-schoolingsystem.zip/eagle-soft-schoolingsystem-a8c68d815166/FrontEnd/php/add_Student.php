<?php
Include("../Send.php");
$tokken          = $_GET['t'];

$arr = array('tokken' => $tokken );
//var_dump($arr);
$var1 = sendRequest("List","BATCH",$arr);

$section = sendRequest("List","SECTION",$arr);

$class = sendRequest("List","CLASS",$arr);

//var_dump($class);

if(isset($_POST['SubmitButton']))
{
	$rollno     	 = $_POST['rollno'];
	$admdate         = $_POST['admdate'];
	$fname       	 = $_POST['fname'];
	$lname           = $_POST['lname'];
	$bid             = $_POST['bid'];
	$dob             = $_POST['dob'];
	$sex             = $_POST['sex'];
	$bgroup          = $_POST['bgroup'];
	$religion        = $_POST['religion'];
	$address         = $_POST['address'];
	$cellno          = $_POST['cellno'];
	$relation        = $_POST['relation'];
	$lastinstitute   = $_POST['lastinstitute'];
	$lastyear        = $_POST['lastyear'];
	$lasttotal       = $_POST['lasttotal'];
	$lastobt  	     = $_POST['lastobt'];
	$entrytotal      = $_POST['entrytotal'];
	$entryobt        = $_POST['entryobt'];
	$entryremarks    = $_POST['entryremarks'];
	$createddate     = $_POST['createddate'];
	$createdby       = $_POST['createdby'];
	$tokken          = $_POST['t'];

	$ffname        	 = $_POST['ffname'];
	$flname          = $_POST['flname'];
	$femail   		 = $_POST['femail'];
	$fcellno         = $_POST['fcellno'];
	$fhomeno         = $_POST['fhomeno'];
	$fworkno  	     = $_POST['fworkno'];
	$fofficeaddress  = $_POST['fofficeaddress'];
	$fdob        	 = $_POST['fdob'];
	$foccupation     = $_POST['foccupation'];
	$fincome     	 = $_POST['fincome'];
	$feducation      = $_POST['feducation'];
	$section     	 = $_POST['section'];
	$class      	 = $_POST['class'];

    $myArray = array('rollno' => $rollno,'admdate' => $admdate,'fname' => $fname,'lname' => $lname,'bid' => $bid,'dob' => $dob,'gender' => $sex ,'bgroup' => $bgroup,'religion' => $religion,'address' => $address,'cellno' => $cellno, 'relation' => $relation,'lastinstitute' => $lastinstitute,'lastyear' => $lastyear,'lasttotal' => $lasttotal,'lastobt' => $lastobt,'entrytotal' => $entrytotal,'entryobt' => $entryobt,'entryremarks' => $entryremarks,'createddate' => $createddate,'createdby' => $createdby, 'tokken' => $tokken, 'ffname' => $ffname, 'flname' => $flname, 'femail' => $femail, 'fcellno' => $fcellno, 'fhomeno' => $fhomeno, 'fworkno' => $fworkno, 'fofficeaddress' => $fofficeaddress, 'fdob' => $fdob, 'foccupation' => $foccupation, 'fincome' => $fincome, 'feducation' => $feducation, 'section' => $section, 'class' => $class );

    echo sendRequest("Insert","STUDENT",$myArray);
}
$var = sendRequest("authenticate","placeholder",$arr);
if($var['userType'] == NULL)
{
  echo '<script>window.location.href = "FrontEndTest.php?E1";</script>';
}

if($var['userType'] == -1)
{
  echo '<script>window.location.href = "login.php?E4";</script>';
}
else
{

?>
<form method="post">
<div>
	<label>Roll No:</label>
	<input type="text" placeholder="First Name" name="rollno" required>
	<br/><br/>
	<label>Admission Date:</label>
	<input type="text" placeholder="First Name" name="admdate" required>
	<br/><br/>
	<label>First Name:</label>
	<input type="text" placeholder="First Name" name="fname" required>
	<br/><br/>
	<label>Last Name:</label>
	<input type="text" placeholder="Last Name" name="lname" required>
	<br/><br/>
	<label>Batch Id:</label>
	<select name="bid">
		<?php 
		for ($i=0; $i < count($var1); $i++) {
		echo '<option value="'.$var1[$i]["id"].'">'.$var1[$i]["name"].'</option>';
	}
		 ?>
	</select>

	<label>Section:</label>
	<select name="section">
		<?php 
		for ($i=0; $i < count($section); $i++) {
		echo '<option value="'.$section[$i]["id"].'">'.$section[$i]["name"].'</option>';
	}
		 ?>
	</select>
	<label>Class:</label>
	<select name="class">
		<?php 
		for ($i=0; $i < count($class); $i++) {
		echo '<option value="'.$class[$i]["id"].'">'.$class[$i]["name"].' '.$class[$i]["group"].'</option>';
	}
		 ?>
	</select>
	<br/><br/>
	<label>DOB:</label>
	<input type="text" placeholder="First Name" name="dob" required>
	<br/><br/>
	<label>Gender:</label>
	<input type="radio" name="sex" value="M" checked>Male
	<input type="radio" name="sex" value="F">Female
	<br><br>
	<label>Blood Group:</label>
	<input type="text" placeholder="First Name" name="bgroup" required>
	<br/><br/>
	<label>Religion:</label>
	<input type="text" placeholder="First Name" name="religion" required>
	<br/><br/>
	<label>Address:</label>
	<input type="text" placeholder="Address" name="address" required>
	<br/><br/>
	<label>Cell Phone:</label>
	<input type="text" placeholder="First Name" name="cellno" required>
	<br/><br/>
	<label>Relation:</label>
	<input type="text" placeholder="First Name" name="relation" required>
	<br/><br/>
	<label>Last Institute:</label>
	<input type="text" placeholder="First Name" name="lastinstitute" required>
	<br/><br/>
	<label>Last Year:</label>
	<input type="text" placeholder="First Name" name="lastyear" required>
	<br/><br/>
	<label>Last Total:</label>
	<input type="text" placeholder="First Name" name="lasttotal" required>
	<br/><br/>
	<label>Last Obtained:</label>
	<input type="text" placeholder="First Name" name="lastobt" required>
	<br/><br/>
	<label>Entry Total:</label>
	<input type="text" placeholder="First Name" name="entrytotal" required>
	<br/><br/>
	<label>Entry Obtained:</label>
	<input type="text" placeholder="First Name" name="entryobt" required>
	<br/><br/>
	<label>Entry Remarks:</label>
	<input type="text" placeholder="First Name" name="entryremarks" required>
	<br/><br/>
	<label>Created At:</label>
	<input type="text" placeholder="First Name" name="createddate" required>
	<br/><br/>
	<label>Created By:</label>
	<input type="text" placeholder="First Name" name="createdby" required>
	<br/><br/>
	<input type="hidden" name="t" value=<?php echo $_GET['t']; ?> >
	<h3>Please Insert Parent Data!!!</h3>
	<label>First Name:</label>
	<input type="text" placeholder="First Name" name="ffname" required>
	<br/><br/>
	<label>Last Name:</label>
	<input type="text" placeholder="First Name" name="flname" required>
	<br/><br/>
	<label>Email:</label>
	<input type="text" placeholder="First Name" name="femail" required>
	<br/><br/>
	<label>Cell No:</label>
	<input type="text" placeholder="First Name" name="fcellno" required>
	<br/><br/>
	<label>Home Phone No:</label>
	<input type="text" placeholder="First Name" name="fhomeno" required>
	<br/><br/>
	<label>Work Phone No:</label>
	<input type="text" placeholder="First Name" name="fworkno" required>
	<br/><br/>
	<label>Office Address:</label>
	<input type="text" placeholder="First Name" name="fofficeaddress" required>
	<br/><br/>
	<label>DOB:</label>
	<input type="text" placeholder="First Name" name="fdob" required>
	<br/><br/>
	<label>Occupation:</label>
	<input type="text" placeholder="First Name" name="foccupation" required>
	<br/><br/>
	<label>Monthly Income:</label>
	<input type="text" placeholder="First Name" name="fincome" required>
	<br/><br/>
	<label>Education:</label>
	<input type="text" placeholder="First Name" name="feducation" required>
	<br/><br/>

	<button type="submit" name='SubmitButton'>Add</button>
</div>
</form>
<?php } ?>