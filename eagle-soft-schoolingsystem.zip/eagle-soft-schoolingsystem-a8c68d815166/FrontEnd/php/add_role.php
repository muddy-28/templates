<?php
Include("../Send.php");

if(isset($_POST['SubmitButton']))
{
	$tokken = $_POST['t'];
	$name        = $_POST['name'];
    $myArray = array('role' => $name, 'tokken' => $tokken );
    echo sendRequest("Insert","ROLE",$myArray);
}
?>
<form method="post">
	<label>Role Name:</label>
	<input type="text" placeholder="Role Name" name="name" required>
	<input type="hidden" name="t" value=<?php echo $_GET['t']; ?> >
	<br/><br/>
	<button type="submit" name='SubmitButton'>Add</button>
</form>