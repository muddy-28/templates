/* set global variable i */

var i = 0;
var j = 0;
var k = 0;

function increment() {
    i += 1; /* function for automatic increament of feild's "Name" attribute*/
}

function increment1() {
    k += 1; /* function for automatic increament of feild's "Name" attribute*/
}

function increment2() {
    j += 1; /* function for automatic increament of feild's "Name" attribute*/
}

/* 
---------------------------------------------

function to remove fom elements dynamically
---------------------------------------------

*/

function removeElement(parentDiv, childDiv) {
    if (childDiv == parentDiv) {
        alert("The parent div cannot be removed.");
    } else if (document.getElementById(childDiv)) {
        var child = document.getElementById(childDiv);
        var parent = document.getElementById(parentDiv);
        parent.removeChild(child);
    } else {
        alert("Child div has already been removed or does not exist.");
        return false;
    }
}


/* 

 ----------------------------------------------------------------------------
 
 functions that will be called upon, when user click on the SubTopicText field
 
 ---------------------------------------------------------------------------
 */
function SubTopicFunction() {
    if(k<5 )
    {       
        var r = document.createElement('span');
        var y = document.createElement("INPUT");
        y.setAttribute("type", "text");
        y.setAttribute("placeholder", "");
       // var g = document.createElement("IMG");
        //g.setAttribute("src", "delete.png");
        increment1();increment2();
        y.setAttribute("Name", "acedemic_info_" +j);
        r.appendChild(y);
       // g.setAttribute("onclick", "removeElement('myForm','subtopic_" + k + "')");
       // r.appendChild(g);
        r.setAttribute("id", "subtopic_" + k);
        document.getElementById("myForm").appendChild(r);
        SubTopicFunction();
    }
    else
    {
        if(k==5)
        {
            
            k=0;
        }
    }
}



/*
-----------------------------------------------------------------------------

functions  that will be called upon, when user click on the Reset Button

------------------------------------------------------------------------------
*/
function resetElements() {
    document.getElementById('myForm').innerHTML = '';
}