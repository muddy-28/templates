<?php

Include("../Send.php");
//echo $_GET['a'];
 $result = sendRequest("logout","placeholder",0);
 // echo $result;
 // var_dump($result);

 if($result['success'])
{
	echo '<script>window.location.href = "login.php?E3";</script>';
}

?>