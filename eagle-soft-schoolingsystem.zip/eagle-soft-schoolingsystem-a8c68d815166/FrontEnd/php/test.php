<?php
$link = mysql_connect("localhost","root","mysql")
  or die(mysql_error());
mysql_select_db("school1") 
  or die (mysql_error());

// echo "result: ".maxID("class","id","1");

function maxID($table,$id){
	$q ="SELECT MAX(".$id.") FROM ".$table;
	$result = mysql_query($q);
	while ($row = mysql_fetch_array($result))
	{
		$ID = $row['MAX(id)'];
	}
	return $ID+1;
}

function maxLikeID($table,$id,$like){
	$q ="SELECT MAX(".$id.") FROM ".$table." WHERE ".$id." LIKE '".$like."%'";
	$result = mysql_query($q);
	while ($row = mysql_fetch_array($result))
	{
		$ID = $row['MAX('.$id.')'];
	}
	return $ID+1;
}

//echo "Roll No Is: ".generateRollno(10);

function generateRollno($classid)
{
	$temp = date("Y");
	$year = $temp[2].$temp[3];

	$prefix = $year.$classid;
	$rollno = maxLikeID("student","roll_no",$prefix);
	$len = strlen($rollno);
	if ($len == 7) {
		return $rollno;
	}else{
		return $prefix."001";
	}
}

// $a = ListSTUDENTClassSection(10,1);
// echo "Result Is: ".var_dump($a);
function ListSTUDENTClassSection($class,$section)
{
	// $class 		= $arr['classid'];
	// $section 	= $arr['sectionid'];
	$q1 = "SELECT * FROM stu_class WHERE class_id = '".$class."' AND section_id = '".$section."' ";
	$result = mysql_query($q1);
	$i = 0;
	while ($row = mysql_fetch_array($result))
		 {
			$stuId = $row['student_id'];
			$q = "SELECT * FROM student WHERE roll_no = '".$stuId."' ";
			$res = mysql_query($q);

			while ($row1 = mysql_fetch_array($res))
			{
				$arr[$i]['id'] = $stuId;
				$arr[$i]['fname'] = $row1['first_name'];
				$arr[$i]['lname'] = $row1['last_name'];
			}
			$i++;
		 }
		 return $arr;
}



function ListTEACHER()
{
	$q1 = "SELECT employee_id FROM employee_type WHERE type_id = 1 ";
	$result = mysql_query($q1);
	$i = 0;
	while ($row = mysql_fetch_array($result))
		 {
			$p = $row['employee_id'];
			$q = "SELECT first_name, last_name FROM employee WHERE employee_id = $p";
			$r = mysql_query($q);
			$res = mysql_fetch_array($r);
			$arr1[$i]['fname'] = $res['first_name'];
			$arr1[$i]['lname'] = $res['last_name'];
			$i++;
		 }
	return $arr1;
}


function ListSTUDENT()
{
	$q1 = "SELECT * FROM student WHERE is_deleted = 0 ";
	$result = mysql_query($q1);
	$i = 0;
	while ($row = mysql_fetch_array($result))
		 {
			$rollno = $row['roll_no'];
			$arr1[$i]['fname'] = $row['first_name'];
			$arr1[$i]['lname'] = $row['last_name'];
			$arr1[$i]['rollno'] = $row['roll_no'];
			$q = "SELECT * FROM stu_class WHERE student_id = ".$rollno;
			$r = mysql_query($q);
			$res = mysql_fetch_array($r);
			$classid 			= $res['class_id'];
			$sectionid 			= $res['section_id'];
//var_dump($arr1);
			$q1 = "SELECT * FROM class WHERE id = '".$classid."' AND is_deleted = 0";
			$r1 = mysql_query($q1);
			$res1 = mysql_fetch_array($r1);
			$arr1[$i]['class'] 	= $res1['name'];
			$arr1[$i]['group'] 	= $res1['group'];

			$q2 = "SELECT * FROM section WHERE id = '".$sectionid."'";
			$r2 = mysql_query($q2);
			$res2 = mysql_fetch_array($r2);
			$arr1[$i]['section'] 	= $res2['name'];
			$i++;
		 }

		 $msg = "Default Message";
	if ($result) {
		$msg = "Everything Is OK";
	}else{
		$msg = "Sorry there is an error at somewhere in execution";
	}
	return $arr1;
	response("OK",$msg,$arr1);
}

$a = ListEMPLOYEE();
var_dump($a);

function ListEMPLOYEE()
{
	$q1 = "SELECT * FROM employee_type WHERE is_deleted = 0 ";
	$result = mysql_query($q1);
	$i = 0;
	while ($row = mysql_fetch_array($result))
		 {
			$empId = $row['employee_id'];
			$typeId = $row['type_id'];
			$q = "SELECT * FROM employee WHERE employee_id = '".$empId."' AND is_deleted = 0";
			$r = mysql_query($q);
			$res = mysql_fetch_array($r);
			$arr1[$i]['id']			= $res['employee_id'];
			$arr1[$i]['fname']		= $res['first_name'];
			$arr1[$i]['lname'] 		= $res['last_name'];

			$q1 = "SELECT * FROM emp_type WHERE id = '".$typeId."' AND is_deleted = 0";
			$r1 = mysql_query($q1);
			$res1 = mysql_fetch_array($r1);
			$arr1[$i]['type'] 	= $res1['type'];
			$i++;
		 }

		 $msg = "Default Message";
	if ($result) {
		$msg = "Everything Is OK";
	}else{
		$msg = "Sorry there is an error at somewhere in execution";
	}
	return $arr1;
	response("OK",$msg,$arr1);
}

?>