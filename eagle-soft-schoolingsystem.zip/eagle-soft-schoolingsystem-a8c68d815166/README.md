# README #

### What is this repository for? ###

* Quick summary:
   This is the full Schooling System to automate the most of the work of any School...
* Version:
   1.0
### How do I get set up? ###

* Summary of set up:
   Mainly we just have to care about few things like: 
   1) "connection to the database" in "connection.php" at api side to check the username, password & DB name
   2) "connection to the api" in "config.php" at front end to check the connection string (directory structure to the api for offline/localhost mode) to the api. 
* Configuration:
  Nothing to configure now...
* Dependencies:
  Nothing dependent now...
* Database configuration:
  Now the credentials for DB are set to be Username: localhost, Password: mysql, DB name: school
* How to run tests:
  For logging in to the system, Please use Username: "test1" or "test2", Password: "123" (for both)...
* Deployment instructions:
  Nothing to deploy till now...


### Who do I talk to? ###

* Repo owner or admin:
  Zeeshan Afzal   11105003@gift.edu.pk
* Other community or team contact:
  Zeeshan Afzal   11105003@gift.edu.pk