<?php
$link = mysql_connect("localhost","root","mysql")
  or die(mysql_error());
mysql_select_db("school1") 
  or die (mysql_error());
  ?>