<?php
//Include("connection.php");
//Include("functions.php");
Include("session.php");
header("Content-Type: application/json");
//JUST FOR GET REQUEST WITH JSON FORMATTED DATA
//$a = $_GET['id'];
$abc = $_POST['posted'];
 //echo $asd["id"];
//var_dump($asd);
//var_dump($final);
// var_dump($a);
//$dic = json_decode($a);


//echo "<<<< JUST STARTED >>>>";
// $order = "Insert";
// $type = "RM";
// $data = array('id' => 1123, 'name' => jeans , 'catid' => 1 , 'whid' => 1 , 'pack' => 2 , 'unit' => 2 , 'style' => nb , 'size' => sm , 'colour' => blue , 'minlevel' => 20 , 'maxlevel' => 2000 , 'dangerlevel' => 10 , 'qty' => 600);
// $arg = array('order' => $order, 'type' => $type, 'data' => $data );

// $send = json_encode($arg);
session_start();


working($abc);

function working($dd)
{
	//echo "stringstringstringstringstringstringstringstring";
//var_dump($dd);
	$total = json_decode($dd, 1);
	$dataFull = $total['data'];
if( isTokkenExist($dataFull['tokken']) || $total['order'] == 'login' )
{
	if ($total['order'] == 'Insert') {
		if ($total['type'] == 'TEACHER') {//////////
			AddTEACHER($total['data']);
		}else if ($total['type'] == 'CLASS') {///////////////
			AddCLASS($total['data']);
		}else if ($total['type'] == 'STUDENT') {
			AddSTUDENT($total['data']);
		}else if ($total['type'] == 'EMPLOYEE') {
			AddEMPLOYEE($total['data']);
		}else if ($total['type'] == 'USER') {///////////////////
			AddUSER($total['data']);
		}else if ($total['type'] == 'ROLE') {///////////////
			AddRole($total['data']);
		}else if ($total['type'] == 'ATTENDANCE') {
			AddATTENDANCE($total['data']);
		}else if ($total['type'] == 'CUS') {
			AddCustomer($total['data']);
		}else if ($total['type'] == 'CAT') {
			AddCategory($total['data']);
		}else if ($total['type'] == 'UNIT') {
			AddUnit($total['data']);
		}else if ($total['type'] == 'SKU') {
			AddSKU($total['data']);
		}else if ($total['type'] == 'DEPT') {
			AddDepartment($total['data']);
		}else if ($total['type'] == 'TRANSFER') {
			AddTRANSFER($total['data']);
		}else{
			echo "<<< DATA CAN'T BE INSERTED Please send an existing type!!! >>>";
		}
	}else if ($total['order'] == 'Fetch') {
		if ($total['type'] == 'PRICE') {
			FetchPrice($total['data']);
		}else if ($total['type'] == 'INV') {
			FetchItemINV($total['data']);
		}else if ($total['type'] == 'WH') {
			FetchItemWH($total['data']);
		}else if ($total['type'] == 'USER') {
			FetchItemUser($total['data']);
		}else if ($total['type'] == 'CELLNO') {
			FetchCELLNO($total['data']);
		}else if ($total['type'] == 'SUP') {
			ItemSupplier($total['data']);
		}else{
			echo "<<< DATA CAN'T BE INSERTED Please send an existing type!!! >>>";
		}
	}else if ($total['order'] == 'Delete') {
		if ($total['type'] == 'INV') {
			DeleteINV($total['data']);
		}else if ($total['type'] == 'WH') {
			DeleteWH($total['data']);
		}else if ($total['type'] == 'USER') {
			DeleteUser($total['data']);
		}else{
			echo "<<< DATA CAN'T BE INSERTED Please send an existing type!!! >>>";
		}
	}else if ($total['order'] == 'Update') {
		if ($total['type'] == 'INV') {
			UpdateINV($total['data']);
		}else if ($total['type'] == 'WH') {
			UpdateWH($total['data']);
		}else if ($total['type'] == 'USER') {
			UpdateUser($total['data']);
		}else{
			echo "<<< DATA CAN'T BE INSERTED Please send an existing type!!! >>>";
		}
	}else if ($total['order'] == 'FetchAllNames') {
		if ($total['type'] == 'ROLE') {///////////////////
			FetchAllNamesROLE();
		}
		if ($total['type'] == 'CAT') {
			FetchAllNamesCAT();
		}
		if ($total['type'] == 'UNIT') {
			FetchAllNamesUNIT();
		}
		if ($total['type'] == 'PACk') {
			FetchAllNamesPACK();
		}
		if ($total['type'] == 'INV_TYPE') {
			FetchAllNamesINV_TYPE();
		}
		if ($total['type'] == 'CUS') {
			FetchAllNamesCUS();
		}
		if ($total['type'] == 'SUP') {
			FetchAllNamesSUP();
		}
		if ($total['type'] == 'DEPT') {
			FetchAllNamesDEPT();
		}
	}else if ($total['order'] == 'FetchAllIds') {
		if ($total['type'] == 'ROLE') { ////////////////////
			FetchAllIdsROLE();
		}
		if ($total['type'] == 'RM') {
			FetchAllIdsRM();
		}
		if ($total['type'] == 'INV') {
			FetchAllIdsINV();
		}
		if ($total['type'] == 'INV_TYPE') {
			FetchAllIdsInvType();
		}
		if ($total['type'] == 'PACK') {
			FetchAllIdsPACK();
		}
		if ($total['type'] == 'SUP') {
			FetchAllIdsSUP();
		}
		if ($total['type'] == 'CUS') {
			FetchAllIdsCUS();
		}
		if ($total['type'] == 'DEPT') {
			FetchAllIdsDEPT();
		}
			
	}else if ($total['order'] == 'FetchAllAdmins') {

			FetchAllAdmins();
	}else if ($total['order'] == 'Generate') {
		if ($total['type'] == 'ROLLNO') {
			generateROLLNO($dataFull['classid']);
		}
	}else if ($total['order'] == 'FetchByClassSection') {
		if ($total['type'] == 'STUDENT') {
			ListSTUDENTClassSection($total['data']);
		}
	}else if ($total['order'] == 'List') 			{
			if ($total['type'] == 'BATCH') {
			ListBATCH();
		}else if ($total['type'] == 'USER') {
			ListUser();
		}else if ($total['type'] == 'SECTION') {
			ListSECTION();
		}else if ($total['type'] == 'CLASS') {
			ListCLASS();
		}else if ($total['type'] == 'EMPTYPE') {
			ListEMPTYPE();
		}else if ($total['type'] == 'COURSE') {
			ListCOURSE($total['data']);
		}else if ($total['type'] == 'TEACHER') {
			ListTEACHER($total['data']);
		}else if ($total['type'] == 'STUDENT') {
			ListSTUDENT($total['data']);
		}else if ($total['type'] == 'EMPLOYEE') {
			ListEMPLOYEE($total['data']);
		}else if ($total['type'] == 'BINS') {
			ListBINS($total['data']);
		}

	}else if ($total['order'] == 'Value') {
		if ($total['type'] == 'WH') {
			ValueWH($total['data']);
		}else if ($total['type'] == 'INV') {
			ValueINV($total['data']);
		}
	}else if ($total['order'] == 'Test') {
		if ($total['type'] == 'DATE') {
			TestDate();
		}else if ($total['type'] == 'BIN') {
			BinMap($total['data']);
		}else if ($total['type'] == 'ItemLevel') {
			ItemLevel($total['data']);
		}
	}
		else if ($total['order'] == 'FetchId') {
		if ($total['type'] == 'WH') {
			FetchIDWH($total['data']);
		}
		if ($total['type'] == 'CAT') {
			FetchIDCAT($total['data']);
		}
		if ($total['type'] == 'UNIT') {
			FetchIDUNIT($total['data']);
		}
		if ($total['type'] == 'ROLE') { ///////////////////
			FetchIDROLE($total['data']);
		}
		if ($total['type'] == 'INV_TYPE') {
			FetchIDINV_TYPE($total['data']);
		}
		if ($total['type'] == 'SUP') {
			FetchIDSUP($total['data']);
		}
		if ($total['type'] == 'PACK') {
			FetchIDPACK($total['data']);
		}
		if ($total['type'] == 'CUS') {
			FetchIDCUS($total['data']);
		}
		if ($total['type'] == 'DEPT') {
			FetchIDDEPT($total['data']);
		}
	 }elseif ($total['order'] == 'login'){
		$recivedArray = $total ['data'];
		//echo "stringstringstringstringstringstringstringstringstringstringstringstringstringstringstringstring";
		login($recivedArray['username'],$recivedArray['password']);
	}else if ($total ['order'] == 'logout'){
		//echo "Logout";
		logout1($total['data']);
	}else if ($total ['order'] == 'authenticate'){

		authenticate(0);
	}else{  //Not Logged In Case OR Not Have required Privliges{
		response("FAIL",'fail',Array('alertBox' => "Please Login First !" ));
	}
}else{
	response("FAIL",'You dont have tokken, Please Login First!!!',Array('alertBox' => "Please Login First !" ));
}
}
//response(OK,12,12);
?>











