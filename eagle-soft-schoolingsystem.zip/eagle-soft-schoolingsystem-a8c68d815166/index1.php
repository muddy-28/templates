<?php
header("Location: FrontEnd/php/login.php");
?>