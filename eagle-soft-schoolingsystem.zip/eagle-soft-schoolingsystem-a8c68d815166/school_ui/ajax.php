<?php
$ok="https://api.clicksend.com/http/v2/send.php?method=http&username=adnanshafique&key=570B3CAC-FC13-4E02-73AA-73089EC80EBF&to=+923246011577&message=Zeeshan+Afzal";
$homepage = file_get_contents($ok);
echo $homepage;
?>