<?php
/**
 * Class login
 * handles the user's login and logout process
 */
class Login
{
    /**
     * @var object The database connection
     */
    private $db_connection = null;
    /**
     * @var array Collection of error messages
     */
    public $errors = array();
    /**
     * @var array Collection of success / neutral messages
     */
    public $messages = array();

    /**
     * the function "__construct()" automatically starts whenever an object of this class is created,
     * you know, when you do "$login = new Login();"
     */
    public function __construct()
    {
        // create/read session, absolutely necessary
        session_start();

        // check the possible login actions:
        // if user tried to log out (happen when user clicks logout button)
        if (isset($_GET["logout"])) {
            $this->doLogout();
        }
        // login via post data (if user just submitted a login form)
        elseif (isset($_POST["login"])) {
            $this->dologinWithPostData();
        }
    }
 
 function sendRequest($order, $type, $data)
{
	$idd = array('order' => $order, 'type' => $type, 'data' => $data );
	$dd = json_encode($idd);
	$final = array('posted' => $dd);

	$url = "http://191.168.6.100/BitBucket/SchoolingSystem/api/";
	$client = curl_init($url);
	curl_setopt($client, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($client, CURLOPT_POST, 1);
	curl_setopt($client, CURLOPT_POSTFIELDS, $final);
	if(isset($_COOKIE['server']))
	{
		curl_setopt($client,CURLOPT_COOKIE,$_COOKIE['server']);
//		echo "Cookie To server ".$_COOKIE['server'];
	}
	
	 curl_setopt($client,CURLOPT_HEADER,1); //
	
	 
	 
	 curl_setopt($client, CURLOPT_VERBOSE, true);
	 
	 $verbose =$fp = fopen('error.txt', 'w'); 
	 curl_setopt($client, CURLOPT_STDERR, $verbose);
	 
	 
	 
	$response1 = curl_exec($client);       //$responce with header
	
	preg_match_all('|Set-Cookie: (.*);|U',$response1,$results); // 
	$cookies = implode(';',$results [1]); //
	                                      // var_dump($cookies); //
	 if($cookies != "")
	 {                                   
		setcookie( "server", $cookies, 0, "/", "", false, true );// 
	 }
	$response2=explode("\n\n", $response1,2);// splited
	$response = $response2[1]; // selected second one
	$result = json_decode($response,1);  
	if ($result["data"] == -1 || $result["data"] == 0) {
		return $result["status_message"];
	}else{
	 	return $result["data"];
	}
}
 
 

    /**
     * log in with post data
     */
    private function dologinWithPostData()
    {
        // check login form contents
        if (empty($_POST['user_name'])) {
            $this->errors[] = "Username field was empty.";
        } 
        if (empty($_POST['user_password'])) 
        {
            $this->errors[] = "Password field was empty.";
        } 
        if (!empty($_POST['user_name']) && !empty($_POST['user_password'])) 
        {    
            $dataToSend = array('username' => $_POST['user_name'], 'password' => $_POST['user_password']);
                        $result = $this->sendRequest("login","placeholder",$dataToSend);
                        var_dump($result);
            if($result['loginStatus'] == "success" )
            {
             $_SESSION['loginStatus'] = $result['loginStatus'];
             $_SESSION['token'] = $result['tokken'];
             $_SESSION['userType'] = $result['userType'];
             $_SESSION['user_login_status'] = 1;
             if($result['userType'] == 7)
              {
                 echo $_SESSION['loginStatus']."i am  test".$_SESSION['token'];
              }

            }
         else if($result['loginStatus'] == "LogedIn" )
            {
             $this->errors[] = "You are already Loggedin....";
             echo "i am  test".$_SESSION['userType'];

            }
         else 
            {
              $this->errors[] = "Something went wrong. Try again.";
            }
        }
    }
    /**
     * perform the logout
     */
    public function doLogout()
    {
        // delete the session of the user
        //$_SESSION = array();
       $result = $this->sendRequest("logout","placeholder",$_SESSION['token']);
          $this->logout();
    }
        /**
     * perform the logout
     */
    public function Logout()
    {
        // delete the session of the user
        $_SESSION = array();
     //  $result = $this->sendRequest("logout","placeholder",$_SESSION['token']);
           session_destroy();
           // return a little feeedback message
           $this->messages[] = "You have been logged out.";
    }

    /**
     * simply return the current state of the user's login
     * @return boolean user's login status
     */
    public function isUserLoggedIn()
    {
        if (isset($_SESSION['user_login_status']) AND $_SESSION['user_login_status'] == 1) {
            return true;
        }
        // default return
        return false;
    }
    



}
