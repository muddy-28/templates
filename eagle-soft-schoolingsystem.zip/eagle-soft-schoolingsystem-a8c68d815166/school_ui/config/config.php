
<?php
//configuration file which have a connection to the server
$_server = "http://191.168.6.100/BitBucket/SchoolingSystem/api/";
?>