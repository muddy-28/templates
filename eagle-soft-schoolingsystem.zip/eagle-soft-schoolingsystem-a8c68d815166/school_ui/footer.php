<footer style="text-align:center;">
        &copy; 2015 EagaleSolutions | By : <a href="http://eagalesoft.com/" target="_blank">Eagale Solutions</a>
    </footer>