<?php

if(isset($_POST['SubmitButton']))
{
  //echo "stringstringstringstringstringstringstringstringstringstringstring";
  $code          = $_POST['code'];
  $meritalstatus   = $_POST['meritalstatus'];
  $fname         = $_POST['fname'];
  $lname           = $_POST['lname'];
  $fathername      = $_POST['fathername'];
  $dob             = $_POST['dob'];
  $sex             = $_POST['sex'];
  $childrens       = $_POST['childrens'];
  $fcnic           = $_POST['fcnic'];
  $mothername      = $_POST['mothername'];
  $bloodgroup      = $_POST['bloodgroup'];
  $husbandname     = $_POST['husbandname'];
  $address         = $_POST['address'];
  $cnic            = $_POST['cnic'];
  $email           = $_POST['email'];
  $createddate     = "17-09-2015";
  $createdby       = 4;
  $tokken          = $_SESSION['token'];


    $myArray = array('code' => $code,'meritalstatus' => $meritalstatus,'fname' => $fname,'lname' => $lname,'fathername' => $fathername,'dob' => $dob,'gender' => $sex ,'childrens' => $childrens,'fcnic' => $fcnic,'mothername' => $mothername,'bloodgroup' => $bloodgroup, 'husbandname' => $husbandname, 'address' => $address,'cnic' => $cnic,'email' => $email, 'createddate' => $createddate,'createdby' => $createdby, 'tokken' => $tokken );

    echo sendRequest("Insert","EMPLOYEE",$myArray);
}


$arr=array('tokken' => $_SESSION['token']);
$var1=sendRequest("List","EMPTYPE",$arr);
?>
<div class="work_area">
        <div class="container">
          <h3 style="margin-top:-1.5%;">Add New Employee</h3>
          <div class="tab-content">
            <div id="home" class="tab-pane fade in active">
              
              <h4>Employee's Bio Data Step - I</h4>
              <h4>All fields marked with <span class="red1">&nbsp;&nbsp;*&nbsp;&nbsp;</span>are required.</h4>


              <form action="" method="post" class="form-horizontal" role="form">
                <div class="less">
                  
                  <label class="control-label">Employee ID<span class="red1">&nbsp;&nbsp;(AUTO GENERATED)</span></label>
                  <input class="form-control" type="text" name="code">

                  <label class="control-label">First Name<span class="red1">&nbsp;&nbsp;*</span></label>
                  <input class="form-control" type="text" name="fname">

                  <label class="control-label">Last Name<span class="red1">&nbsp;&nbsp;*</span></label>
                  <input class="form-control" type="text" name="lname">

                  <label class="control-label">Date of Birth<span class="red1">&nbsp;&nbsp;*</span></label>
                  <input class="form-control" type="date" name="dob">

                  <label class="control-label">Gender<span class="red1">&nbsp;&nbsp;*</span></label>
                  <select name="sex" class="form-control">
                    <option>Male</option>
                    <option>Female</option>
                  </select>

                  <label class="control-label">CNIC #<span class="red1">&nbsp;&nbsp;*</span></label>
                  <input class="form-control" type="text" name="cnic">




                
                <br>

                
                <br>
                <a data-toggle="pill" class="btn btn-primary" href="#menu1">Next</a>
                </div>
            </div>
            <div id="menu1" class="tab-pane fade">
              
              <h4>Bio Data Step-II</h4>
              <div class="less">
                <label class="control-label">Martial Status<span class="red1">&nbsp;&nbsp;*</span></label>
                <select class="form-control" name="meritalstatus">
                  <option>Married</option>
                  <option>Un-Married</option>
                </select>

                <label class="control-label">Children Count<span class="red1">&nbsp;&nbsp;*</span></label>
                <input type="number" class="form-control" name="childrens">

                <label class="control-label">Father's Name<span class="red1">&nbsp;&nbsp;*</span></label>
                <input class="form-control" type="text" name="fathername">
                
                <label class="control-label">Husband's Name
                <span class="red1">&nbsp;&nbsp;(REQUIRED IN CASE OF MARRIED FEMALE EMPLOYEE)</span></label>
                <input class="form-control" type="text" name="husbandname">

                <label class="control-label">Blood Group</label>
                <select name="bgroup" class="form-control">
                  <option>A+</option>
                  <option>A-</option>
                  <option>B+</option>
                  <option>B-</option>
                  <option>O+</option>
                  <option>O-</option>
                  <option>AB+</option>
                  <option>AB-</option>
                </select>

                <label class="control-label">Religion</label>
                <input class="form-control" type="text" name="religion">

                <br>
                <br>
                <a data-toggle="pill" class="btn btn-primary" href="#home">back</a>
                <a data-toggle="pill" class="btn btn-primary" href="#menu2">Next</a>
              </div>
              <br>

            </div>
              
              <div id="menu2" class="tab-pane fade">
                
              <h4>Contact Information</h4>
              <div class="less">
                
                <label class="control-label">E-mail<span class="red1">&nbsp;&nbsp;*</span></label>
                <input class="form-control" type="email" name="email">
                
                <label class="control-label">Cell #<span class="red1">&nbsp;&nbsp;*</span></label>
                <input class="form-control" type="text" name="cellno">
                
                <label class="control-label">Address<span class="red1">&nbsp;&nbsp;*</span></label>
                <textarea class="form-control" name="address" maxlength="300" placeholder="Not more than 300 characters"></textarea>
                
                
                <br>
                <br>
                <a class="btn btn-primary" data-toggle="pill" href="#menu1">Back</a>
                <a class="btn btn-primary" data-toggle="pill" href="#menu3">Next</a>
              </div>
              <br>

            </div>
              
              <div id="menu3" class="tab-pane fade">
                
              <h4>Specify Employee Type</h4>
              <div class="less">
                
                <label class="control-label">Employee Type<span class="red1">&nbsp;&nbsp;*</span></label>
                <select class="form-control" name="emptype">
                  <?php 
    for ($i=0; $i < count($var1); $i++) {
    echo '<option value="'.$var1[$i]["id"].'">'.$var1[$i]["type"].'</option>';
  }
     ?>
                </select>
                
                <br>
                <br>
                <a class="btn btn-primary" data-toggle="pill" href="#menu2">Back</a>
                <a class="btn btn-primary" data-toggle="pill" href="#menu4">Next</a>
              </div>
              <br>

            </div>
              
            <div id="menu4" class="tab-pane fade">
<!--               <h4>Employee Acedemics</h4>
              <div class="less">
                <button class="btn btn-primary" type="button" onclick="SubTopicFunction()">New Acedemic Record</button>
                <button class="btn btn-warning" onclick="resetElements()">Reset</button>
                
                <br><br>
               
                
                <span id="myForm" class="test"></span>
                
                <br>
                <br> -->
                <a data-toggle="pill" class="btn btn-primary" href="#menu3">Back</a>
                <button class="btn btn-primary" type="submit" name="SubmitButton">Submit!</button>
              </div>
              <br>

            </div>
            </form> 
            
              
              
          </div>
        </div>
      </div>