<?php
$arr=array('tokken' => $_SESSION['token']);
$class=sendRequest("List","CLASS",$arr);


?>
  <div class="work_area col-sm-12 grey">
    <form action="index.php?page=add_student_step1&menu=student_menu" class="" id="" role="form" method="post">

      <div class="col-sm-4">

        <select class="form-control" name="class">
          <?php 
              for ($i=0; $i < count($class); $i++) 
              {
                echo '<option value="'.$class[$i]["id"].'">'.$class[$i]["name"].' '.$class[$i]["group"].'</option>';
              }
          ?>
        </select>
      </div>


      <div class="col-sm-4">
        <button class="btn btn-primary" type="submit">Submit</button>
      </div>

    </form>
  </div>