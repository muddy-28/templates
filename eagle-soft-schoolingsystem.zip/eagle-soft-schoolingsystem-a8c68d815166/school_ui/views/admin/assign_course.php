<?php
$arr=array('tokken' => $_SESSION['token']);
$course=sendRequest("List","COURSE",$arr);
$teacher=sendRequest("List","TEACHER",$arr);
$class=sendRequest("List","CLASS",$arr);
$section=sendRequest("List","SECTION",$arr);
?>
<div class="work_area col-sm-12 grey">
        <form action="" class="" id="" role="form">
        
          <div class="col-sm-8">
                <label class="control-label">Course Name<span class="red">&nbsp;&nbsp;*</span></label><br>
                <select class="form-control" name="course">
                  <?php
                    for($i=0; $i < count($course); $i++)
                    {
                      echo '<option value="'.$course[$i]["id"].'">'.$course[$i]["name"].'</option>';
                    }
                  
                  ?>
                </select>
          </div>
          <br><br><br>
          <div class="col-sm-8"> 
                <label class="control-label">Teacher Name<span class="red">&nbsp;&nbsp;*</span></label><br>
                <select class="form-control" name="teacher">
                  <?php
                    for($i=0; $i < count($teacher); $i++)
                    {
                      echo '<option value="'.$teacher[$i]["id"].'">'.$teacher[$i]["fname"].''." ".$teacher[$i]["lname"].'</option>';
                    }
                  
                  ?>
                </select>
          </div>
          
          <br><br><br>
          <div class="col-sm-8"> 
                <label class="control-label">Class Name<span class="red">&nbsp;&nbsp;*</span></label><br>
                <select class="form-control" name="class">
                  <?php
                    for($i=0; $i < count($class); $i++)
                    {
                      echo '<option value="'.$class[$i]["id"].'">'.$class[$i]["name"].' '.$class[$i]["group"].'</option>';
                    }
                  
                  ?>
                </select>
          </div>
          
          <br><br><br>
          <div class="col-sm-8"> 
                <label class="control-label">Section Name<span class="red">&nbsp;&nbsp;*</span></label><br>
                <select class="form-control" name="section">
                  <?php
                    for($i=0; $i < count($section); $i++)
                    {
                      echo '<option value="'.$section[$i]["id"].'">'.$section[$i]["name"].'</option>';
                    }
                  
                  ?>
                </select>
          </div>
          <br><br><br><br>
          <div class="col-sm-8">
            <a class="btn btn-primary" href="">Assign Course</a>&nbsp;&nbsp;
            <a class="btn btn-warning" href="">Reset</a>
          </div>
        
        </form>
      </div>