<?php


$arr=array('tokken' => $_SESSION['token']);
$class=sendRequest("List","CLASS",$arr);
$section=sendRequest("List","SECTION",$arr);


?>

<div class="work_area">
        <h3>Attendence System -> New Attendence </h3>
        <br>
        <div class="att_filter col-sm-12">
          <form class="" id="" method="post" role="form">
            
            <div class="col-sm-5">
<!--              <label class="control-label">Class</label>-->
              <select class="form-control" name="class">
                
                <?php 
    for ($i=0; $i < count($class); $i++) {
    echo '<option value="'.$class[$i]["id"].'">'.$class[$i]["name"].' '.$class[$i]["group"].'</option>';
  }
     ?>
              </select>
            </div>
            
            <div class="col-sm-5">
<!--              <label class="control-label">Section</label>-->
              <select class="form-control" name="section">
                <?php 
    for ($i=0; $i < count($section); $i++) {
    echo '<option value="'.$section[$i]["id"].'">'.$section[$i]["name"].'</option>';
  }
     ?>
              </select>
            </div>
            
            
            
            <div class="col-sm-1">
              <button class="btn btn-primary" type="submit" name="submitButton">Load</button>
            </div>
            
            <div class="col-sm-1">
              <button class="btn btn-warning" type="reset">Reset</button>
            </div>
          
          </form>
        </div>
        <div class="clear"></div>
        <hr class="tall">
        
        
          <?php

if(isset($_POST['submitButton']))
{
  $class=$_POST['class'];
  $section=$_POST['section'];
  
  $myData=array("tokken"=>$_SESSION['token'], "classid"=>$class, "sectionid"=>$section);
  $result=sendRequest("FetchByClassSection","STUDENT",$myData);
  
  if($result==1)
  {
    echo '<h3 class="text-center">No student is registered in this class.</h3>'; 
    //$flag=false; 
  }
  else
  {
    echo '<div class="att_table col-sm-12"></div>';
              echo '<form class="" id="" method="" role="form">';  
              echo '<table class="table table-hover table-bordered">';
              echo '<thead>';
              echo '<tr>';
                echo '<th class="col-sm-2">ID</th>';
                echo '<th class="col-sm-8">Name</th>';
                echo '<th class="col-sm-2">Status</th>';
              echo '</tr>';
            echo '</thead>';
            echo '<tbody>';
              for($i=0; $i < count($result); $i++)
              {
                   echo '<tr>';
                echo '<td>'; echo $result[$i]["id"]; echo '</td>';
                echo '<td>'; echo $result[$i]["fname"]." ".$result[$i]["lname"]; echo '</td>';
                echo '<td><select name="att" class="from-control col-sm-12"><option> </option><option>P</option><option>A</option></select></td>
              </tr>';
 
              }
              
              echo '</from>';
              echo '</div>';
    //$flag=true; 
  }

  
}







//            if($flag && isset($_POST['submitButton']))
//            {
//                    //table
//              echo '<div class="att_table col-sm-12"></div>';
//              echo '<form class="" id="" method="" role="form">';  
//              echo '<table class="table table-hover table-bordered">';
//              echo '<thead>';
//              echo '<tr>';
//                echo '<th class="col-sm-2">ID</th>';
//                echo '<th class="col-sm-8">Name</th>';
//                echo '<th class="col-sm-2">Status</th>';
//              echo '</tr>';
//            echo '</thead>';
//            echo '<tbody>';
//              for($i=0; $i < count($result); $i++)
//              {
//                   echo '<tr>';
//                echo '<td>'; echo $result[$i]["id"]; echo '</td>';
//                echo '<td>'; echo $result[$i]["fname"]." ".$result[$i]["lname"]; echo '</td>';
//                echo '<td><select name="att" class="from-control col-sm-12"><option> </option><option>P</option><option>A</option></select></td>
//              </tr>';
// 
//              }
//              
//              echo '</from>';
//              echo '</div>';
//            }
//
//            else if(!$flag && isset($_POST['submitButton']))
//            {
//                echo '<h3 class="text-center">Oops :( Nothing Found.</h3>'; 
//            }

        ?>
      </div>