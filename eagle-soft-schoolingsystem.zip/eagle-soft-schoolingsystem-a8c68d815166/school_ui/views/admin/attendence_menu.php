  <div class="left_menu">
  <div class="list-group">
  <a href="#" class="list-group-item active">
    Attendence Management
  </a>
  <a href="index.php?page=attendence&menu=attendence_menu" class="list-group-item">New Attendence</a>
  <a href="index.php?page=edit_attendence&menu=attendence_menu" class="list-group-item">Edit Attendence</a>
  <a href="index.php?page=view_attendence&menu=attendence_menu" class="list-group-item">View Attendence</a>
</div>
</div>