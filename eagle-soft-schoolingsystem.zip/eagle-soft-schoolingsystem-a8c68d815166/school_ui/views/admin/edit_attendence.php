<?php


$arr=array('tokken' => $_SESSION['token']);
$class=sendRequest("List","CLASS",$arr);
$section=sendRequest("List","SECTION",$arr);


?>

<div class="work_area">
        <h3>Attendence System -> Edit Attendence </h3>
        <br>
        <div class="att_filter col-sm-12">
          <form class="" id="" method="" role="form">
            
            <div class="col-sm-3">
<!--              <label class="control-label">Class</label>-->
              <select class="form-control" name="class">
                <?php 
    for ($i=0; $i < count($class); $i++) {
    echo '<option value="'.$class[$i]["id"].'">'.$class[$i]["name"].' '.$class[$i]["group"].'</option>';
  }
     ?>
              </select>
            </div>
            
            <div class="col-sm-3">
<!--              <label class="control-label">Section</label>-->
              <select class="form-control" name="section">
                <?php 
    for ($i=0; $i < count($section); $i++) {
    echo '<option value="'.$section[$i]["id"].'">'.$section[$i]["name"].'</option>';
  }
     ?>
              </select>
            </div>
            
            <div class="col-sm-3">
<!--              <label class="control-label">Date</label>-->
              <input type="date" name="date" class="form-control" placeholder="Select Date MM/DD/YYYY">
            </div>
            
            <div class="col-sm-1">
              <button class="btn btn-primary" type="submit">Edit</button>
            </div>
            
            <div class="col-sm-1">
              <button class="btn btn-warning" type="reset">Reset</button>
            </div>
          
          </form>
        </div>
        <div class="clear"></div>
        <hr class="tall">
        
        <div class="att_table col-sm-12">
          
          <form class="" id="" method="" role="form">  
          <table class="table table-hover table-bordered">
            <thead>
              <tr>
                <th class="col-sm-2">ID</th>
                <th class="col-sm-8">Name</th>
                <th class="col-sm-2">Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>11105007</td>
                <td>Shahzaib Ahmed</td>
                <td><select name="att" class="from-control col-sm-12"><option> </option><option>P</option><option>A</option></select></td>
              </tr>
              <tr>
              
            </tbody>
          </table>
          <button class="btn btn-primary col-sm-2">Update Attendence</button><div class="col-xs-1"></div>
          <button class="btn btn-warning col-sm-2">Reset</button>
          </form>
        </div>
        
      </div>