<div class="left_menu">
<div class="list-group">
          <a class="list-group-item active">
            <i class="glyphicon glyphicon-user"></i>&nbsp;&nbsp;Manage Employees
          </a>
          <a href="index.php?page=view_employee&menu=employee_menu" class="list-group-item"><i class="glyphicon glyphicon-list-alt"></i>&nbsp;&nbsp;Employees List</a>
          <a href="index.php?page=add_employee&menu=employee_menu" class="list-group-item"><i class="glyphicon glyphicon-plus"></i>&nbsp;&nbsp;Create New Employee</a>
          <a href="#" class="list-group-item"><i class="glyphicon glyphicon-wrench"></i>&nbsp;&nbsp;Manage Employee</a>
        </div>
  
  <div class="list-group">
          <a class="list-group-item active"><i class="glyphicon glyphicon-user"></i>&nbsp;&nbsp;Teachers Operations</a>
          <a class="list-group-item" href="index.php?page=assign_course&menu=employee_menu"><i class="glyphicon glyphicon-user"></i>&nbsp;&nbsp;Assign Courses</a>
    
        </div>
      

</div>