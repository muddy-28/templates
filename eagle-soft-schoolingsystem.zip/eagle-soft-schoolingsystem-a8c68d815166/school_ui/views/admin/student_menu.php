<div class="left_menu">
        <div class="list-group">
          <a class="list-group-item active">
            <i class="glyphicon glyphicon-user"></i>&nbsp;&nbsp;Manage Students
          </a>
          <a href="index.php?page=view_student&menu=student_menu" class="list-group-item"><i class="glyphicon glyphicon-list-alt"></i>&nbsp;&nbsp;Student List</a>
          <a href="index.php?page=add_student&menu=student_menu" class="list-group-item"><i class="glyphicon glyphicon-plus"></i>&nbsp;&nbsp;Create New Student</a>
          <a href="#" class="list-group-item"><i class="glyphicon glyphicon-wrench"></i>&nbsp;&nbsp;Manage Students</a>
        </div>
        
        </div>