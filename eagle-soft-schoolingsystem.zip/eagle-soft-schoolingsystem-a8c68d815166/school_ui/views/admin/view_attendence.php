<div class="work_area">
        <h3>Attendence System</h3>
        <br>
        <div class="att_filter col-sm-12">
          
            
            <div class="col-sm-3">
<!--              <label class="control-label">Class</label>-->
              <select class="form-control" name="class">
                <option>-------Filter By-------</option>
                <option>Person</option>
                <option>Class</option>
                <option>Teacher</option>
                <option>Batch</option>
              </select>
            </div>
            
          
          
        </div>
        <div class="clear"></div>
        <hr class="tall">
        
        <div class="att_table col-sm-12">
          
          <form class="" id="" method="" role="form">  
          <table class="table table-hover table-bordered">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Date</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>11105007</td>
                <td>Shahzaib Ahmed</td>
                <td>12-1-2015</td>
                <td>P</td>
              </tr>
              <tr>
              
            </tbody>
          </table>
          
          
        </div>
        
      </div>