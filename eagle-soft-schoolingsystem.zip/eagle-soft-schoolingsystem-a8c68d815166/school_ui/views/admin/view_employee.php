<?php
$arr=array("tokken" => $_SESSION['token']);
$result=sendRequest("List","EMPLOYEE",$arr);
?>
<div class="work_area">
        <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Employee Type</th>
      </tr>
    </thead>
    <tbody>
      
      <?php
      
      for($i=0; $i < count($result); $i++)
      {
      echo '<tr>';
        echo '<td>'; echo $result[$i]["id"]; echo '</td>';
        echo '<td>'; echo $result[$i]["fname"];echo '</td>';
        echo '<td>'; echo $result[$i]["lname"];echo '</td>';
        
        echo '<td>'; echo $result[$i]["type"];echo '</td>';
        
      echo '</tr>';
      }
      ?>
    </tbody>
  </table>
      
      </div>