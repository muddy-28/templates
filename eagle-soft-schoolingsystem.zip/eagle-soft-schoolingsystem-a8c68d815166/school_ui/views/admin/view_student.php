<?php
$arr=array("tokken" => $_SESSION['token']);
$result=sendRequest("List","STUDENT",$arr);
?>
<div class="work_area">
        <table class="table table-striped">
    <thead>
      <tr>
        <th>ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Class</th>
        <th>Section</th>
      </tr>
    </thead>
    <tbody>
      
      <?php
      
      for($i=0; $i < count($result); $i++)
      {
      echo '<tr>';
        echo '<td>'; echo $result[$i]["rollno"]; echo '</td>';
        echo '<td>'; echo $result[$i]["fname"];echo '</td>';
        echo '<td>'; echo $result[$i]["lname"];echo '</td>';
        echo '<td>'; echo $result[$i]["class"]."  ".$result[$i]["group"];echo '</td>';
        echo '<td>'; echo $result[$i]["section"];echo '</td>';
        
      echo '</tr>';
      }
      ?>
    </tbody>
  </table>
      
      </div>