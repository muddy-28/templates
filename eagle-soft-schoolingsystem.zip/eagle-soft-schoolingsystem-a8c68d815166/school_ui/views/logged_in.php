<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>Welcome - Home</title>
  <script src="assets/js/dynamic_row_table.js" type="text/javascript"></script>

  <style>
    .body {
      background-color: #555554;
    }
  </style>


  <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
  <div class="container">
    <div class="upper_buttons">
      <div class="btn-group btn-group-justified">
        <a type="button" href="index.php" class="btn btn-large btn-primary"><i class="glyphicon glyphicon-home"></i><br>Home</a>
        <a type="button" href="index.php?page=view_student&menu=student_menu" class="btn btn-large btn-primary"><i class="glyphicon glyphicon-user"></i><br>Students</a>
        <a type="button" href="index.php?menu=employee_menu&page=view_employee" class="btn btn-large btn-primary"><i class="glyphicon glyphicon-user"></i><br>Employees</a>
        <a type="button" class="btn btn-large btn-primary"><i class="glyphicon glyphicon-book"></i><br>Courses</a>
        <a type="button" class="btn btn-large btn-primary"><i class="glyphicon glyphicon-list-alt"></i><br>Examination</a>
        <a type="button" href="index.php?menu=attendence_menu&page=view_attendence" class="btn btn-large btn-primary"><i class="glyphicon glyphicon-tags"></i><br>Attendence</a>
        <a type="button" class="btn btn-large btn-primary"><i class="glyphicon glyphicon-paperclip"></i><br>Time Table</a>
        <a type="button" class="btn btn-large btn-primary"><i class="glyphicon glyphicon-usd"></i><br>Fees</a>
        <a type="button" class="btn btn-large btn-primary"><i class="glyphicon glyphicon-list-alt"></i><br>Reports</a>
        <a type="button" class="btn btn-large btn-primary"><i class="glyphicon glyphicon-cog"></i><br>Settings</a>
        <div class="btn-group">
          <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
            <i class="glyphicon glyphicon-info-sign"></i>
            <br>Others <span class="caret"></span></button>
          <ul class="dropdown-menu" role="menu">
            <li><a href="#"><i class="glyphicon glyphicon-home"></i>&nbsp;&nbsp;Hostel</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-plane"></i>&nbsp;&nbsp;Transport</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-book"></i>&nbsp;&nbsp;Library</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-download"></i>&nbsp;&nbsp;Downloads</a></li>
            <li><a href="#"><i class="glyphicon glyphicon-envelope"></i>&nbsp;&nbsp;Messaging</a></li>
            <li><a href="index.php?logout"><i class="glyphicon glyphicon-off"></i>&nbsp;&nbsp;Logout</a></li>
          </ul>
        </div>


      </div>
    </div>
    <div class="breadcrumb custom_margins">
      Home -> Students -> Manage Students
    </div>
    

    
    <div class="container2">
      
      
        

      <div class="filter_buttons">

      </div>
      <div class="form_filters">

      </div>
        <head>
    <meta charset="utf-8" />
    <title>My jQuery Ajax test</title>
    <style type="text/css">
      #mybox {
        width: 400px;
        height: 20px;
        border: 1px solid #999;
      }
    </style>
    <script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
    <script>              
        function myCall() {
          var request = $.ajax({
            url: "ajax.php",
            type: "GET",      
            dataType: "html"
          });

          request.done(function(msg) {
            $("#mybox").html(msg);      
          });

          request.fail(function(jqXHR, textStatus) {
            alert( "Request failed: " + textStatus );
          });
        }
      
    </script>
  </head>
  <body>
    Message Sending status<br />
    <div id="mybox">
      
    </div>
    <input type="button" value="Update" onclick="myCall()" />

  </body>
      <?php
      if(isset($_GET['menu']))
      {
        $menu="views//admin//".$_GET['menu'].".php";
        include($menu); 
      }  ?>
      
      <?php
      if(isset($_GET['page']))
      {
        $page="views//admin//".$_GET['page'].".php";
        include($page); 
      }  ?>
    </div>

  </div>

  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script><hr class="tall"></hr><br>
</body>

</html>