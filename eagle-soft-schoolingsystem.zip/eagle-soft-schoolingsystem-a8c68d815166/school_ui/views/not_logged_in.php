<?php
// show potential errors / feedback (from login object)
if (isset($login)) {
    if ($login->errors) {
        foreach ($login->errors as $error) {
            echo $error;
        }
    }
    if ($login->messages) {
        foreach ($login->messages as $message) {
            echo $message;
        }
    }
}
?>

    <link href="assets/css/not_logged_in.css" rel="stylesheet">

    <div class="container">
        <div class="logo">
            <img src="media/brand_image.png" class="img-responsive" alt="Brand Image">
        </div>
        <div class="text">
            <h4>Eagle Solutions &copy; School Management System &trade;</h4>
        </div>
        <hr class="tall">
        <div class="login_window">
            <form action="index.php" method="post" class="form-horizontal" enctype="multipart/form-data">
                <?php
                    // show potential errors / feedback (from login object)
                    if (isset($login)) {
                        if ($login->errors) {
                            foreach ($login->errors as $error) {
                                echo $error;
                            }
                        }
                        if ($login->messages) {
                            foreach ($login->messages as $message) {
                                echo $message;
                            }
                        }
                    }
                    ?>
                    <div class="form-group">
                        <label class="col-sm-5" for="username">Username:</label>
                        <div class="col-sm-12">
                            <input id="login_input_username" class="form-control" type="text" name="user_name" placeholder="User Id here" required autofocus>
                            <br>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-5" for="password">Password:</label>
                        <div class="col-sm-12">
                            <input id="login_input_username" class="form-control" name="user_password" type="password" placeholder="****">

                        </div>
                    </div>
                    <button name="login" type="submit" class="btn btn-block btn-primary"><i class="glyphicon glyphicon-ok"></i>&nbsp;&nbsp;Sign In</button>
                    <button name="reset" type="reset" class="btn btn-block btn-warning"><i class="glyphicon glyphicon-remove"></i>&nbsp;&nbsp;Reset</button>

            </form>
        </div>
        <br>
        <hr class="tall">

    </div>